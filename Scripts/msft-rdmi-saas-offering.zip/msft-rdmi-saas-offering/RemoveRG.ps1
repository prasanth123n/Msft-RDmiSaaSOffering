﻿param
(

    [Parameter(Mandatory = $True)]
    [ValidateNotNullOrEmpty()]
    [string] $RGName,

    
    [Parameter(Mandatory = $True)]
    [ValidateNotNullOrEmpty()]
    [string] $Location

)

try
{
    Write-Output "Checking if the resource group $RGName exists";
    $RG = Get-AzureRmResourceGroup -Name $RGName -ErrorAction SilentlyContinue
    if ($RG)
    {
        Write-Output "Deleting the resource group $RGName ...";
        Remove-AzureRmResourceGroup -Name $RGName -Location $Location -ErrorAction Stop 
        Write-Output "Resource group with name $RGName has been deleted"
    }
}
catch [Exception]
{
    Write-Output $_.Exception.Message
}